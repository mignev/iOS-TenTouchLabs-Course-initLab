//
//  TTArrayTests.h
//  xml
//
//  Created by Dani Rangelov on 12/20/11.
//  Copyright (c) 2011 Ten Touch. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TTArrayTests : NSObject {
    
    //NSMutableArray *_myArray;
}

@property(nonatomic, retain) NSMutableArray *myArray;

+(void)demoArray;
+(NSMutableDictionary*)loadDictFromPlist;

@end
